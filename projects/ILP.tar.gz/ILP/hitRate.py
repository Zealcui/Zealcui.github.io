__author__ = 'zhichengcui'
from util import *
import os


def kdd15(base):
    cmd = 'Rscript getTree.R ' + base
    os.system(cmd)
    path = "./R_RF_csv/" + base + "/"
    output_name = 'sparse_' + base

    NUM_TREE = 0
    for filename in os.listdir(path):
        if filename.startswith('Tree'):
            NUM_TREE += 1
    #print "The num of tree is ",NUM_TREE
    Total_var = 0
    Data = {}
    variable = []
    Var = {} #each feature and its split point
    for file_int in xrange(0,NUM_TREE):
        ind = '%d' %file_int
        fileName = path + "Tree" + ind
        cate,Data[file_int] = loadData(fileName)
        for data in Data[file_int]:
            if data[3] == '0':
                continue
            if Var.has_key(data[3]) == False:
                #print "Add feature ",data[3]
                Var[data[3]] = []
                variable.append(data[3])

            if Var[data[3]].__contains__(string.atof(data[4])) == False:
                Var[data[3]].append(string.atof(data[4]))
    feature_choice = [None] * (len(Var)) #because the feature is from 1 to n (continuous)
    #print "**** The total number of feature is: ", len(Var)
    #variable.sort()
    for k in Var:
        Var[k].sort()
        feature_choice[variable.index(k)] = len(Var[k]) + 1
        #print "**** The total number of partition for feature ",k, "is: ", len(Var[k]) + 1
    #get the tree with ordered interval
    Tree = {}
    import copy
    for i in xrange(0,NUM_TREE):
        data = Data[i]
        queue = []
        Clauses = []
        clause = {}
        queue = [(clause,0)]
        while queue:
            clause, ind = queue.pop(0)
            line = data[ind]
            if line[6] == '1':
                Clauses.append(clause)
                continue
            if line[6] == '2':
                continue
            spli_var = line[3]
            spli_val = string.atof(line[4])
            """old version
            left_clause = copy.deepcopy(clause)#left side is less of equal
            if left_clause.has_key(spli_var) == True:
                if left_clause[spli_var][0] > spli_val:
                    raise StandardError #Error at this time
                if left_clause[spli_var][1] > spli_val:
                    left_clause[spli_var][1] = spli_val
            else:
                left_clause[spli_var] = [-float('inf'), spli_val]

            queue.append((left_clause, string.atoi(line[1])-1 ))

            right_clause = copy.deepcopy(clause)
            if right_clause.has_key(spli_var) == True:
                if right_clause[spli_var][1] < spli_val:
                    raise StandardError
                if right_clause[spli_var][0] < spli_val:
                    right_clause[spli_var][0] = spli_val
            else:
                right_clause[spli_var] = [spli_val, float('inf')]

            queue.append((right_clause, string.atoi(line[2])-1))
            """
            #new version

            spli_index = Var[spli_var].index(spli_val)
            left_clause = copy.deepcopy(clause)
            if left_clause.has_key(spli_var) == True:
                if left_clause[spli_var][0] > spli_index:
                    raise StandardError #Error at this time
                if left_clause[spli_var][1] > spli_index:
                    left_clause[spli_var][1] = spli_index
            else:
                left_clause[spli_var] = [-1, spli_index]

            queue.append((left_clause, string.atoi(line[1])-1 ))

            right_clause = copy.deepcopy(clause)
            if right_clause.has_key(spli_var) == True:
                if right_clause[spli_var][1] < spli_index:
                    raise StandardError
                if right_clause[spli_var][0] < spli_index:
                    right_clause[spli_var][0] = spli_index
            else:
                right_clause[spli_var] = [spli_index, len(Var[spli_var])]

            queue.append((right_clause, string.atoi(line[2])-1))
        Tree[i] = Clauses

    #compute how much variables that we need

    #the starting point of Phi
    base_phi = {} #  # of phi for each tree
    start_phi = sum(feature_choice)
    """old version
    for i in xrange(0,NUM_TREE):
        clauses = Tree[i]
        base_phi[i] = [0] * (len(clauses) + 1) #the last value for next use
        if i > 0:
            base_phi[i][0] = base_phi[i - 1][len(Tree[i-1])] #use the last value here
        for j in xrange(0,len(clauses)):#clause is a list
            num = 1
            for k,v in clauses[j].iteritems(): # clause[i] is a dict, containing feature and its interval.
                num = num * (v[1] - v[0])
            base_phi[i][j + 1] = base_phi[i][j] + num
    """
    #new version
    for i in xrange(0,NUM_TREE):
        #Clauses = Tree[i]
        if i == 0:
            base_phi[i] = start_phi
        else:
            base_phi[i] = base_phi[i-1] + len(Tree[i - 1])

    base_phi[NUM_TREE] = base_phi[NUM_TREE - 1] + len(Tree[NUM_TREE - 1])
        

    Total_var = base_phi[NUM_TREE]
    #print "DIM is ", Total_var
    #constuct the parameter
    Equations = [None] * len(Var) # all the variable constraints
    for k, v in Var.iteritems():
        feature_ind = variable.index(k)#string.atoi(k)
        Equations[feature_ind] = [0] * Total_var
        for i in xrange(0, len(v) + 1):
            pos = findVarPos(feature_choice,feature_ind,i)
            Equations[feature_ind][pos] = 1

    #print "**** The total number of equality constraints is : ", len(Var)
    
    Inequalities = [None] * (base_phi[NUM_TREE] - base_phi[0] + 1) # all the clause constraints and the vote contraints
    param_ind = 0
    for i in xrange(0,NUM_TREE):
        Clauses = Tree[i]
        for j in xrange(len(Clauses)):
            clause = Clauses[j]
            Inequalities[param_ind] = [0] * Total_var
            for k, v in clause.iteritems():
                feature_ind = variable.index(k)#string.atoi(k)
                for interval in xrange(v[0] + 1,v[1] + 1):#because the interval starts from -1
                    pos = findVarPos(feature_choice, feature_ind, interval)
                    Inequalities[param_ind][pos] = -1
            phi_pos = base_phi[i] + j
            Inequalities[param_ind][phi_pos] = len(clause)
            param_ind += 1

    #handle the single vote inequalition
    Inequalities[param_ind] = [0] * Total_var
    for i in xrange(base_phi[0], Total_var):
        Inequalities[param_ind][i] = -1
    param_ind += 1

    #print "**** The total number of inequality constraints is : ",param_ind

    testFile = path + 'x_neg'
    trainFile = path + 'x_pos'

    print 'Processing ', base

    cate,testData = loadData(testFile)
    cate,trainData = loadData(trainFile)
    trainSet = trainTransform(Var,trainData,variable)
    #test = neg_test
    import random
    import time
    resultName = "./result_" + base
    costName = "./cost_" + base
    fp = open(resultName,'w')
    fcost = open(costName,'w')
    lazybest = {}
    timelazy = {}
    greedybest = {}
    timegreedy = {}
    ilp = {}
    ilp_time = {}
    change_opt_flag = {}
    for myind in xrange(len(testData)):
        lazybest[myind] = -1
        timelazy[myind] = -1
        greedybest[myind] = -1
        timegreedy[myind] = -1
        ilp[myind] = -1
        ilp_time[myind] = -1
        change_opt_flag[myind] = True

    fail_time = 0              
    for rand_time in xrange(1): #10 random cost
        cost = [0] * len(Var)
        cost_content = ""
        for j in xrange(len(Var)):
            cost[j] = int(random.uniform(1,100))
            cost_content += ("%d" %cost[j] + " ")
        cost_content += "\n"
        fcost.write(cost_content)
        fcost.flush()
        valid_num = 0
        #ilp = ""
        #ilp_time = ""
        #timelazy = 0
        #timegreedy = 0
        for i in xrange(0,30):#len(testData)): #10 sample
            dest_result = "%d" %rand_time + " " + "%d" %i + " "
            testSample = testData[i][1:]
            #print "The ", rand_time, "th random cost, ", i, "th test sample of ", base
            out = output_name + '_' + '%d' %i + '.dat'
            out = "./my_ilp.dat"

            if lazybest[i] == -1:
                time1 = time.time()
                lazybest[i] = lazyCompare(testSample,trainSet, Var,variable) # improve it by passing a list of samples instead of just one
                time2 = time.time()
                timelazy[i] = time2 - time1
                greedybest[i],changed_features = greedyChange(testSample,Tree, Var,variable)
                time22 = time.time()
                timegreedy[i] = time22 - time2
            if greedybest[i] == 1000000:
                fail_time = fail_time + 1 
        print base," hit rate is ", (30.0 - fail_time) /30.0
    fp.close()
    fcost.close()
   # doubleCheck("check.txt",start_phi,feature_choice,Tree)
    #os.system("ampl start.run")

    print "Finished"


if __name__ == "__main__":
    #base = 'breast'
    DataSet = ['heart','liver-disorders','breast-cancer','australian','ionosphere_scale', #'satimage.scale',
               'a1a','mushrooms']
    #for data_set in DataSet[1:2]:
    #    kdd15(data_set)
    #kdd15("liver-disorders")
    for data_set in DataSet: #['a1a','covtype.libsvm.binary','cod-rna']:
    	kdd15(data_set)


