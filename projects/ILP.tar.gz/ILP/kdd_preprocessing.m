mydata = importdata('KDDTrain+_20Percent.txt');
data = mydata.textdata;
x = data(:,1:41);
y = data(:,42);
[n,d] = size(x);

protocol_type = {'tcp','udp', 'icmp'};
service =  {'auth','bgp', 'courier','csnet_ns','ctf','daytime','discard','domain'...
    , 'domain_u','echo','eco_i',  'ecr_i',  'efs', 'exec','finger','ftp', ...
    'ftp_data','gopher', 'hostnames','http','http_443','http_8001','imap4', ...
    'IRC', 'iso_tsap','klogin', 'kshell', 'ldap','link','login','mtp', 'name',...
    'netbios_dgm' 'netbios_ns' , 'netbios_ssn','netstat','nnsp','nntp','ntp_u',...
    'other','pm_dump','pop_2',  'pop_3',  'printer','private','red_i', ...
    'remote_job'  'rje', 'shell',  'smtp','sql_net','ssh', 'sunrpc', 'supdup', ...
    'systat','telnet', 'tim_i',  'time','urh_i',  'urp_i', 'uucp','uucp_path',...
    'vmnet',  'whois',  'X11','Z39_50'};
flag =  { 'OTH', 'REJ', 'RSTO', 'RSTOS0', 'RSTR', 'S0', 'S1', 'S2', 'S3', 'SF', 'SH' };
class = {'normal', 'anomaly'};
ind = find(strcmp(protocol_type,'tcp'));

X = zeros(n,117);
Y = zeros(n,1);
for i = 1:n
    for j = 1:d
        if j == 2
            X(i,j + find(strcmp(protocol_type,x{i,j})) - 1) = 1;
        elseif j == 3
            X(i,j + 1 + find(strcmp(service,x{i,j}))) = 1;
        elseif j == 4
            X(i,j + 66 + find(strcmp(flag,x{i,j}))) = 1;
        elseif j == 21
            continue;
        elseif j < 21
            X(i,j + 77) = str2double(x{i,j});
        else
            X(i,j + 76) = str2double(x{i,j});
        end
    end
    if strcmp(y{i,1},'normal')
        Y(i) = 0;
    else
        Y(i) = 1;
    end
    if mod(i,1000) == 1
        display(['Current is ', num2str(i)]);
    end
end
save('kdd99.mat','X','Y');
