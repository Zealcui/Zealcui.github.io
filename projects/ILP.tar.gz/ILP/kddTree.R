#args <- commandArgs(TRUE)
#matName <- as.character(args[1])         #= "german.numer_scale"
library(randomForest)
library(foreign)
#data = R.matlab::readMat(paste(matName,".mat",sep=""))
data = read.arff("./KDDTrain+_20Percent.arff")
x = data[,1:41]
y = data[,42]
#y = label$Y
#0 positive, 1 negtive
#spilt the data to 50/50 parts
num_tree = 20
N = length(y)
index = sample(N)
stop = floor(N * 0.5)
index_train =index[1:stop]
index_test = index[(stop+1):N] 
x_train = x[index_train,]
y_train = y[index_train]
x_test = x[index_test,]
y_test = y[index_test]

#building the RF model
set.seed(36)
rf =randomForest(x_train,y_train,ntree=num_tree,importance=TRUE,proximity=TRUE,nodesize=5)
#,nodesize=5
#predict
pred <- predict(rf,x_train)
pred = as.numeric(pred)-1
#pred = pred*2 -1

#accuracy
TF = (as.factor(y_train)==pred)
acc = sum(TF)/length(TF)
print(acc)

#save the training example
ind_ori_neg = (y_train == 1)
x_ori_neg = x_train[ind_ori_neg,]#including the misclassified sample in training set
ind_neg = (ind_ori_neg == TF)
x_neg = x_train[ind_neg,]

ind_ori_pos = (y_train == 0)
x_ori_pos = x_train[ind_ori_pos,]
ind_pos = (ind_ori_pos == TF)
x_pos = x_train[ind_pos,]
baseName = paste("./R_RF_csv/",matName,sep="")
dir.create(baseName)
f1 = paste(baseName,"/x_ori_neg.csv",sep="")
f2 = paste(baseName,"/x_neg.csv",sep="")
f3 = paste(baseName,"/x_ori_pos.csv",sep="")
f4 = paste(baseName,"/x_pos.csv",sep="")
write.csv(x_ori_neg,file=f1)
write.csv(x_neg, file=f2)
write.csv(x_ori_pos,file=f3)
write.csv(x_pos,file=f4)

pred <- predict(rf,x_test)
pred = as.numeric(pred)-1
#pred = pred*2 -1

#accuracy
TF = (as.factor(y_test)==pred)
acc = sum(TF)/length(TF)
print(acc)
#feature selection using function rfcv
#result <- rfcv(x,y,5)

baseName="./R_RF_csv/"
baseName = paste(baseName,matName,sep="")
baseName = paste(baseName, "/Tree",sep="")
for(i in 0:(num_tree - 1)){
name = paste(baseName, i, sep="")
e = getTree(rf, k=i+1, labelVar=FALSE)
name = paste(name,".csv",sep="")
write.csv(e,file=name)
}
