args <- commandArgs(TRUE)
matName <- as.character(args[1])         #= "german.numer_scale"
library(randomForest)
data = R.matlab::readMat(paste(matName,".mat",sep=""))
x = data$X
#y = label$Y
y = data$Y
y[y==-1] = 0
#1 positive, 0 negtive
#spilt the data to 50/50 parts
for(i in 1:dim(x)[2]){
    mini <- min(x[,i])
    maxi <- max(x[,i])
    if(mini == maxi){
	x[j,i] <- 1 #all the values are same
        next
    }
    for(j in 1:dim(x)[1]){
	x[j,i] <- (x[j,i] - mini)/(maxi - mini)
    }
}
num_tree = 200
N = length(y)
index = sample(N)
if(N >= 3000){
	stop = 1000
	N = 3000
}else{
	stop = floor(N * 0.5)
}
index_train =index[1:stop]
index_test = index[(stop+1):N] 
x_train = x[index_train,]
y_train = y[index_train]
x_test = x[index_test,]
y_test = y[index_test]

#building the RF model
set.seed(36)
y_train <- as.factor(y_train )
rf =randomForest(x_train,y_train,ntree=num_tree,importance=TRUE,proximity=TRUE,nodesize=3)
#,nodesize=5
#predict
pred <- predict(rf,x_test)
pred = as.numeric(pred)-1
#pred = pred*2 -1

#accuracy
TF = (as.factor(y_test)==pred)
acc = sum(TF)/length(TF)
print(acc)

#save the training example
ind_ori_neg = (y_test == 1)
x_ori_neg = x_test[ind_ori_neg,]#including the misclassified sample in training set
ind_neg = (ind_ori_neg == TF)
x_neg = x_test[ind_neg,]

pred <- predict(rf,x_train)
pred = as.numeric(pred)-1
#pred = pred*2 -1

#accuracy
TF = (as.factor(y_train)==pred)
ind_ori_pos = (y_train == 0)
x_ori_pos = x_train[ind_ori_pos,]
ind_pos = (ind_ori_pos == TF)
x_pos = x_train[ind_pos,]
baseName = paste("./R_RF_csv/",matName,sep="")
dir.create(baseName)
#f1 = paste(baseName,"/x_ori_neg.csv",sep="")
f2 = paste(baseName,"/x_neg.csv",sep="")
#f3 = paste(baseName,"/x_ori_pos.csv",sep="")
f4 = paste(baseName,"/x_pos.csv",sep="")
#write.csv(x_ori_neg,file=f1)
write.csv(x_neg, file=f2)
#write.csv(x_ori_pos,file=f3)
write.csv(x_pos,file=f4)

pred <- predict(rf,x_test)
pred = as.numeric(pred)-1
#pred = pred*2 -1

#accuracy
TF = (as.factor(y_test)==pred)
acc = sum(TF)/length(TF)
print(acc)
#feature selection using function rfcv
#result <- rfcv(x,y,5)

baseName="./R_RF_csv/"
baseName = paste(baseName,matName,sep="")
baseName = paste(baseName, "/Tree",sep="")
for(i in 0:(num_tree - 1)){
name = paste(baseName, i, sep="")
e = getTree(rf, k=i+1, labelVar=FALSE)
name = paste(name,".csv",sep="")
write.csv(e,file=name)
}
quit()
