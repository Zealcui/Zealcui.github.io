__author__ = 'zhichengcui'

import string
import csv
import copy
import math
import cPickle
def writeCSVFile(filePointer,list):
    for i in range(len(list)):
        if i==len(list)-1:
            filePointer.write(list[i]+'\n')
        else:
            filePointer.write(list[i]+',')

def getColum(allData,ColumNumber):
    result=[]
    for i in range(len(allData)):
        result.append(allData[i][ColumNumber])
    return result

def getDict(allData,ColumNumber):
    result={}
    for i in range(len(allData)):
        result[allData[i][0]]=allData[i][ColumNumber]
    return result

def loadData(fileName):
    reader = csv.reader(file(fileName+'.csv', 'rb'))
    i=0
    allData=[]
    for line in reader:
        i+=1
        if i==1:
            catagory=line
        else:
            allData.append(line)
    return catagory,allData

def findVarPos(feature_choice, feature_ind, feature_interval):
    if feature_ind == 0:
        return feature_interval
    base = 0
    for i in xrange(1,feature_ind+1):
        base = base + feature_choice[i-1]
    return base + feature_interval

def testTransform(Var, testSample,variable):
    clause = {}

    for ind in xrange(len(testSample)):
        feature = "%d" %(ind + 1)
        if variable.__contains__(feature) == False:
            continue
        feature_ind = variable.index(feature)
        clause[feature] = [-1, len(Var[feature])]
        intervals = Var[feature]
        sample_value = string.atof(testSample[ind])
        for j in xrange(len(intervals)):
            if sample_value > intervals[j]:
                clause[feature][0] = j

            if sample_value <= intervals[j]:
                clause[feature][1] = j
                break
    return clause
def trainTransform(Var, trainData,variable):
    Clauses = []
    for trainSample in trainData:
        clause = {}
        trainSample = trainSample[1:]
        for ind in xrange(len(trainSample)):
            feature = '%d' %(ind + 1)
            if variable.__contains__(feature) == False:
                continue
            feature_ind = variable.index(feature)
            clause[feature] = [-1, len(Var[feature])]
            intervals = Var[feature]
            sample_value = string.atof(trainSample[ind])
            for j in xrange(len(intervals)):
                if sample_value > intervals[j]:
                    clause[feature][0] = j

                if sample_value <= intervals[j]:
                    clause[feature][1] = j
                    break
        Clauses.append(clause)
    return Clauses

def writeConsAMPL(fp, var_name, Total_var, equations):
    head = 'param '
    head += (var_name + ':')
    ind = range(1, Total_var + 1)
    str_ind = ind.__str__()
    str_ind  = str_ind.replace('[',' ')
    str_ind  = str_ind.replace(']',' ')
    str_ind  = str_ind.replace(',','')
    head += str_ind
    head += ' :=\n'

    fp.write(head)
    for i in xrange(1, len(equations) + 1):
        base = '%d' %i
        line = equations[i - 1].__str__()
        line = line.replace('[',' ')
        if i == len(equations):
            line = line.replace(']',';\n')
        else:
            line = line.replace(']','\n')
        line = line.replace(',','')
        fp.write(base + line)

def writeSparseAMPL(fp, var_name, Total_var, equations):
    head = 'param '
    head += (var_name + ':=\n')
    fp.write(head)
    for i in xrange(1, len(equations) + 1):
        param = equations[i - 1]
        row = '%d' %i
        for j in xrange(1,Total_var + 1):
            if param[j - 1] != 0:
                line = row + ' ' + '%d' %j + ' ' + '%d' %param[j - 1] + '\n'
                fp.write(line)
    fp.write(';\n')

def getObj(test, Var, Total_var,feature_choice,start_phi,variable):
    sample = testTransform(Var,test,variable)
    obj = [0] * Total_var
    for k, v in sample.iteritems():
        feature_ind = variable.index(k)#string.atoi(k)
        for interval in xrange(v[0] + 1, v[1] + 1):
            pos = findVarPos(feature_choice, feature_ind, interval)
            obj[pos] = 1

    for i in xrange(start_phi):
        if obj[i] == 0:
            obj[i] = 1;
        else:
            obj[i] = 0;
    return obj
def getObjWithCost(test, Var, Total_var,feature_choice,start_phi,variable,cost):
    sample = testTransform(Var,test,variable)
    obj = [0] * Total_var
    for k, v in sample.iteritems():
        feature_ind = variable.index(k)#string.atoi(k)
        for interval in xrange(0,len(Var[k]) + 1):
            if interval == v[1]:
                continue
            elif interval < v[1]:
                pos = findVarPos(feature_choice, feature_ind, interval)
                obj[pos] = int((cost[feature_ind] * (string.atof(test[string.atoi(k)-1]) - Var[k][interval]))*1000)
            else:
                pos = findVarPos(feature_choice, feature_ind, interval)
                obj[pos] = int((cost[feature_ind] * (Var[k][interval-1] - string.atof(test[string.atoi(k)-1])))*1000)
    return obj
def saveDat(output_name, test, Var, Total_var, Equations, Inequalities, Tree,feature_choice, start_phi,variable):

    obj = getObj(test, Var, Total_var,feature_choice, start_phi,variable)
    fp = open(output_name,'w')
    line = 'param DIM:='
    line = line + '%d' %Total_var + ';\n'
    fp.write(line)
    line = 'param N_eq:='
    line += '%d' %len(Equations) + ';\n'
    fp.write(line)
    line = 'param N_postree:=' + '%d' %(-(len(Tree)+1)/2) + ';\n'
    fp.write(line)
    line = 'param N_ineq:='
    line += '%d' %len(Inequalities) + ';\n'
    fp.write(line)
    #print line
    #writeConsAMPL(fp,'eq_cons',Total_var,Equations)
    #writeConsAMPL(fp,'ineq_cons', Total_var, Inequalities)
    writeSparseAMPL(fp,'eq_cons', Total_var,Equations)
    writeSparseAMPL(fp,'ineq_cons', Total_var, Inequalities)

    lines = 'param object := \n'
    for i in xrange(1, len(obj) + 1):
        if obj[i - 1] == 0:
            continue
        base = '%d' %i
        c = '%d' %obj[i-1]
        lines = lines + base + ' ' + c + '\n'
    lines += ';\n'
    fp.writelines(lines)
    fp.close()

def saveDatWithCost(output_name, test, Var, Total_var, Equations, Inequalities, Tree,feature_choice, start_phi,variable, cost):

    obj = getObjWithCost(test, Var, Total_var,feature_choice, start_phi,variable,cost)
    fp = open(output_name,'w')
    line = 'param DIM:='
    line = line + '%d' %Total_var + ';\n'
    fp.write(line)
    line = 'param N_eq:='
    line += '%d' %len(Equations) + ';\n'
    fp.write(line)
    line = 'param N_postree:=' + '%d' %(-(len(Tree)+1)/2) + ';\n'
    fp.write(line)
    line = 'param N_ineq:='
    line += '%d' %len(Inequalities) + ';\n'
    fp.write(line)
    #print line
    #writeConsAMPL(fp,'eq_cons',Total_var,Equations)
    #writeConsAMPL(fp,'ineq_cons', Total_var, Inequalities)
    writeSparseAMPL(fp,'eq_cons', Total_var,Equations)
    writeSparseAMPL(fp,'ineq_cons', Total_var, Inequalities)

    lines = 'param object := \n'
    for i in xrange(1, len(obj) + 1):
        if obj[i - 1] == 0:
            continue
        base = '%d' %i
        c = '%d' %obj[i-1]
        lines = lines + base + ' ' + c + '\n'
    lines += ';\n'
    fp.writelines(lines)
    fp.close()

def lazyCompare(testSample, trainSet, Var,variable):
    sample = testTransform(Var,testSample,variable)
    best = len(Var)
    for trainSample in trainSet:
        curr = 0
        for k, v in sample.iteritems():
            if v[0] != trainSample[k][0]:
                curr += 1
        if curr < best:
            best = curr
    return best

def lazyCompareWithCost(testSample, trainSet, Var,variable,cost):
    sample = testTransform(Var,testSample,variable)
    best = float('Inf')
    for trainSample in trainSet:
        curr = 0
        for k, v in sample.iteritems():
            feature_ind = variable.index(k)
            if v[0] != trainSample[k][0]:
                if v[0] > trainSample[k][0]:
                    curr += cost[feature_ind] * (string.atof(testSample[string.atoi(k)-1]) - Var[k][trainSample[k][1]] )
                else:
                    curr += cost[feature_ind] * (Var[k][trainSample[k][0]] - string.atof(testSample[string.atoi(k)-1]))
                #curr += 1
        if curr < best:
            best = curr
    return best

def checkSupport(sample, Tree):
    base_support = 0
    for i in xrange(len(Tree)):
        tree = Tree[i]
        for clause in tree:
            vote = True
            for k, v in clause.iteritems():
                if sample[k][0] < v[0] or sample[k][1] > v[1]:
                    vote = False
            if vote:
                base_support += 1
                break #break means that we do not need to keep searching for this tree since we've already got satisfied.
    return base_support

def greedyChange(testSample, Tree, Var, variable,n = 0): # n is the maximum number that we want to change, default is the # of variable
    if n == 0:
        n = len(Var)
    sample = testTransform(Var, testSample,variable)
    new_sample = copy.deepcopy(sample)
    base_support = checkSupport(sample, Tree)
    change_order = []
    if base_support >= (len(Tree) + 1)/2:
        return [len(change_order),[]]
    for i in xrange(n):
        curr_best_support = [base_support, -1, -2]# -1 key -2 interval_left
        for k, v in sample.iteritems():
            #if k == '5':
            #    continue
            init_ind = v[0]
            num_intervals = len(Var[k]) + 1
            for j in xrange(-1, num_intervals - 1):
                if j == v[0]:
                    continue
                new_sample[k][0] = j
                new_sample[k][1] = j + 1
                support = checkSupport(new_sample,Tree)
                if curr_best_support[0] < support:
                    curr_best_support = [support, k, j]
            new_sample[k] = [init_ind, init_ind + 1]

        change_order.append(curr_best_support)
        base_support,k,j = curr_best_support
        if j == -2:
            return [1000000,[]]
        if base_support >= (len(Tree) + 1)/2:
            return [len(change_order),change_order]
        new_sample[k] = [j, j + 1]

    return [1000000,[]]

def greedyChangeWithCost(testSample, Tree, Var, variable,cost, n = 0): # n is the maximum number that we want to change, default is the # of variable
    if n == 0:
        n = len(Var)
    sample = testTransform(Var, testSample,variable)
    new_sample = copy.deepcopy(sample)
    base_support = checkSupport(sample, Tree)
    change_order = []
    if base_support >= (len(Tree) + 1)/2:
        return 0 #change_order
    for i in xrange(n):
        curr_best_support = [base_support, -1, -2]# -1 key -2 interval_left
        for k, v in sample.iteritems():
            init_ind = v[0]
            num_intervals = len(Var[k]) + 1
            for j in xrange(-1, num_intervals - 1):
                if j == v[0]:
                    continue
                new_sample[k][0] = j
                new_sample[k][1] = j + 1
                support = checkSupport(new_sample,Tree)
                if curr_best_support[0] < support:
                    curr_best_support = [support, k, j]
            new_sample[k] = [init_ind, init_ind + 1]

        change_order.append(curr_best_support)
        base_support,k,j = curr_best_support
        if j == -2:
            return 1000000
        if base_support >= (len(Tree) + 1)/2:
            finalCost = 0
            for base_support,k,j in change_order:
                feature_ind = variable.index(k)
                if j < sample[k][0]:
                    finalCost += cost[feature_ind] * (string.atof(testSample[string.atoi(k)-1]) - Var[k][j + 1])
                elif j > sample[k][0]:
                    finalCost += cost[feature_ind] * (Var[k][j] - string.atof(testSample[string.atoi(k)-1]))
            return finalCost#change_order
        new_sample[k] = [j, j + 1]

    return 1000000#change_order No soln

def greedyChangeWithCostWise(testSample, Tree, Var, variable,cost, n = 0): # n is the maximum number that we want to change, default is the # of variable
    if n == 0:
        n = len(Var)
    sample = testTransform(Var, testSample,variable)
    new_sample = copy.deepcopy(sample)
    base_support = checkSupport(sample, Tree)
    print "base support is ", base_support
    change_order = []
    if base_support > len(Tree)/2:
        return 0 #change_order
    for i in xrange(n):
        curr_best_support = [0, base_support, -1, -2]# -1 key -2 interval_left
        for k, v in sample.iteritems():
            feature_ind = variable.index(k)
            init_ind = v[0]
            num_intervals = len(Var[k]) + 1
            for j in xrange(-1, num_intervals - 1):
                if j == v[0]:
                    continue
                new_sample[k][0] = j
                new_sample[k][1] = j + 1
                if j < v[0]:
                    curr_cost = cost[feature_ind] * (string.atof(testSample[string.atoi(k)-1]) - Var[k][j + 1])
                    if curr_cost < 0:
                        print "Error!!!"
                else:
                    curr_cost = cost[feature_ind] * (Var[k][j] - string.atof(testSample[string.atoi(k)-1]))
                    if curr_cost < 0:
                        print "Error!!!"
                support = checkSupport(new_sample,Tree)
                ori_support = curr_best_support[1]
                quality = (support - ori_support)/(curr_cost + 0.001)
                if curr_best_support[0] < quality:
                    curr_best_support = [quality, support, k, j]
            new_sample[k] = [init_ind, init_ind + 1]

        change_order.append(curr_best_support)
        qua,base_support,k,j = curr_best_support
        if j == -2:
            return 1000000
        if base_support > len(Tree)/2:
            finalCost = 0
            for qua,base_support,k,j in change_order:
                feature_ind = variable.index(k)
                if j < sample[k][0]:
                    finalCost += cost[feature_ind] * (string.atof(testSample[string.atoi(k)-1]) - Var[k][j + 1])
                elif j > sample[k][0]:
                    finalCost += cost[feature_ind] * (Var[k][j] - string.atof(testSample[string.atoi(k)-1]))
            return finalCost#change_order
        new_sample[k] = [j, j + 1]

    return 1000000#change_order No soln


def doubleCheck(check_name, start_phi, feature_choice, Tree):

    fp = open(check_name,'r')
    myTest = []
    for line in fp:
        line = line.strip(' ')
        line = line.strip('\n')
        line = line.split(' ')
        i = 0
        while i < (len(line) - 1):
            if line[i] == '':
                i += 1
                continue
            if line[i + 1] == '0':
                i += 2
                continue
            ind = string.atoi(line[i])
            if ind >= start_phi:
                i += 2
                continue
            myTest.append(ind)
            i += 2
    #compSample = testTransform(Var,testSample)
    #print "The original support is ", checkSupport(compSample,Tree)
    sample = {}
    for k in myTest:
        if k <= feature_choice[0]:
            sample['1'] = [k -2, k - 1]
            continue
        for j in xrange(len(feature_choice) -1):
            k = k - feature_choice[j]
            if k < feature_choice[j + 1]:
                sample['%d' %(j+2)] = [k - 2, k - 1]
    support = checkSupport(sample,Tree)
    print "The pos tree is ", support, ". And total is ", len(Tree)
    return support > len(Tree)

